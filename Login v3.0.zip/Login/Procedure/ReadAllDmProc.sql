CREATE PROCEDURE ReadAllDmProc
	
AS
BEGIN
	SELECT * FROM DecryptedMessage
END