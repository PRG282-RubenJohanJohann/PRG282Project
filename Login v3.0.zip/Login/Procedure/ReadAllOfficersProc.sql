CREATE PROCEDURE ReadAllOfficersProc
AS
BEGIN
	SELECT Name, Surname, Age, Rank, Identification_number, Username, Password FROM tblOfficer
END