﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class TheAdminApp : Form
    {
        public TheAdminApp()
        {
            InitializeComponent();
            DisplayGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        public void UpdateDisplay()
        {
            BindingSource bs = new BindingSource();
            Controller controller = new Controller();
            List<User> Details = new List<User>();

            Details = controller.ReadAllOfficersController();
            bs.DataSource = Details;
            DisplayGrid.DataSource = bs;
            DisplayGrid.Columns["Username"].Visible = false;
            DisplayGrid.Columns["Password"].Visible = false;
        }

        private void TheAdminApp_Load(object sender, EventArgs e)
        {
            UpdateDisplay();    
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            List<User> details = new List<User>();
            details = controller.ReadAllOfficersController();
            string name = TxtName.Text;
            string surname = TxtSurname.Text;
            int age = int.Parse(TxtAge.Text);
            string rank = TxtRank.Text;

            foreach (User item in details)
            {
                int results = controller.UpdateOfficerController(name, surname, age, rank,item.Username);
                MessageBox.Show(string.Format("{0} row(s) effected", results));
                break;
            }

            UpdateDisplay();
        }

        private void DisplayGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            User user = (User)DisplayGrid.SelectedRows[0].DataBoundItem;
            TxtName.Text = user.Name;
            TxtSurname.Text = user.Surname;
            TxtAge.Text = user.Age.ToString();
            TxtRank.Text = user.Rank;
            
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            string name = TxtName.Text;
            string surname = TxtSurname.Text;
            int age = int.Parse(TxtAge.Text);
            string rank = TxtRank.Text;
            string username = TxtUsername.Text;
            string password = TxtPassword.Text;

            int results = controller.InsertOfficerController(name, surname, age, rank, username, password);
            MessageBox.Show(string.Format("{0} row(s) effected", results));
            UpdateDisplay();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string username = TxtUsername.Text;
            Controller controller = new Controller();

            int results = controller.UpdateOfficerController(username);
            MessageBox.Show(string.Format("{0} row(s) effected", results));
            UpdateDisplay();
        }
    }
}
