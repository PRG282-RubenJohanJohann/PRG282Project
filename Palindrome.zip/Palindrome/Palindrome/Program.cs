﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
        }


        public static bool IsPalindrome(string[] words)
        {
            string phrase = "";
            foreach (string word in words)
            {
                phrase = phrase + word[0];
            }
            if (phrase == (string)phrase.Reverse())
            {
                return true;
            }
            else return false;
        }
    }

}
