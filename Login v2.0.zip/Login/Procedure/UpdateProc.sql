CREATE PROCEDURE UpdateProc
	@name VARCHAR(50),
	@surname VARCHAR(50),
	@age INT,
	@rank VARCHAR(50),
	@username VARCHAR(50)
AS
BEGIN
	UPDATE tblOfficer SET Name=@name, Surname=@surname, Age=@age, Rank=@rank WHERE Username=@username
END