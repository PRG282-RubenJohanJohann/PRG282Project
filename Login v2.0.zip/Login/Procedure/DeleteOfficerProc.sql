CREATE PROCEDURE DeleteOfficerProc
	@username VARCHAR(50)
AS
BEGIN
	DELETE FROM tblOfficer WHERE Username=@username
END