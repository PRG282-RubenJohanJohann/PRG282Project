﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class TheApp : Form
    {
        public TheApp()
        {
            InitializeComponent();
        }

        private void TheApp_Load(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            Controller controller = new Controller();
            List<User> Details = new List<User>();

            Details = controller.ReadAllOfficersController();
            bs.DataSource = Details;
            
            DisplayGridLowRank.DataSource = bs;
            DisplayGridLowRank.Columns["Username"].Visible = false;
            DisplayGridLowRank.Columns["Password"].Visible = false;
        }
    }
}
