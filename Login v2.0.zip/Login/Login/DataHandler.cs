﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Login
{
    class DataHandler
    {
        SqlConnection conn;
        //SqlConnectionStringBuilder builder;
        public DataHandler()
        {
            // builder = new SqlConnectionStringBuilder();
            // builder.DataSource = @"localhost\SQLEXPRES";
            // builder.InitialCatalog = "Login";
            // builder.IntegratedSecurity = true;
            conn = new SqlConnection(@"Data Source=RUBEN\SQLEXPRESS;Initial Catalog=Military;Integrated Security=True");
        }

        public DataTable ReadAllOfficers()
        {
            DataTable result = new DataTable();
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "ReadAllOfficersProc";
                cmd.Connection = conn;
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(result);
            }
            catch (SqlException SqlEx)
            {
                MessageBox.Show(SqlEx.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }

        public int UpdateOfficer(string name, string surname, int age, string rank, string username)
        {
            int result = 0;
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                string proc = "UpdateProc";
                SqlCommand cmd = new SqlCommand(proc);
                cmd.CommandType = CommandType.StoredProcedure;               
                cmd.Connection = conn;
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@surname", surname);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.Parameters.AddWithValue("@rank", rank);
                cmd.Parameters.AddWithValue("@username", username);
                result = cmd.ExecuteNonQuery();
            }
            catch (SqlException SqlEx)
            {

                MessageBox.Show(SqlEx.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }

        public int InsertOfficer(string name, string surname, int age, string rank, string username, string password)
        {
            int result = 0;
            try
            {
                if (conn.State!=ConnectionState.Open)
                {
                    conn.Open();
                }
                string proc = "InsertOfficerProc";
                SqlCommand cmd = new SqlCommand(proc);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@surname", surname);
                cmd.Parameters.AddWithValue("@age", age);
                cmd.Parameters.AddWithValue("@rank", rank);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                result = cmd.ExecuteNonQuery();
            }
            catch (SqlException SqlEx)
            {

                MessageBox.Show(SqlEx.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }

        public int DeleteOfficer(string username)
        {
            int result = 0;
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                string proc = "DeleteOfficerProc";
                SqlCommand cmd = new SqlCommand(proc);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                cmd.Parameters.AddWithValue("@username", username);
                result = cmd.ExecuteNonQuery();
            }
            catch (SqlException SqlEx)
            {

                MessageBox.Show(SqlEx.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }

    }
}
