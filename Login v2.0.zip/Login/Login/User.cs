﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Login
{
    class User
    {
        private Int64 IdentificationNumber;
        private string name;
        private string surname;
        private int age;
        private string rank;
        private string username;
        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Username
        {
            get { return username; }
            set { username = value; }
        }
        

        public string Rank
        {
            get { return rank; }
            set { rank = value; }
        }
        

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        

        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        

        public Int64 IdentificationNumber1
        {
            get { return IdentificationNumber; }
            set { IdentificationNumber = value; }
        }
        

        

        public User(string name, string surname, int age, string rank, long IdentificationNumber,string username, string password)
        {
            this.IdentificationNumber = IdentificationNumber;
            this.name = name;
            this.surname = surname;
            this.age = age;
            this.rank = rank;
            this.username = username;
            this.password = password;
        }
    }
}
