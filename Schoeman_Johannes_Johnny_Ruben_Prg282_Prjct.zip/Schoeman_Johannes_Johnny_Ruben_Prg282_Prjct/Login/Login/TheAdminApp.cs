﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class TheAdminApp : Form
    {
        
        public TheAdminApp(User user)
        {
            InitializeComponent();
        }

        private void TheAdminApp_Load(object sender, EventArgs e)
        {

        }

        private void messageControll1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            userManagementControl1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            userViewControl1.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            messageControll1.BringToFront();
        }

        private void messageControll1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
