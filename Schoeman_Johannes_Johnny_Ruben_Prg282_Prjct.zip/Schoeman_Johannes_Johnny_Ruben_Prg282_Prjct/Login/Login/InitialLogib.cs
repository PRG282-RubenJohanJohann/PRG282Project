﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class InitialLogib : Form
    {
        public InitialLogib()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string username = TxtUsername.Text;
            string password = TxtPassword.Text;
            List<User> ReadAllList = new List<User>();
            Controller control = new Controller();
            ReadAllList = control.ReadAllOfficersController();
            bool isValid = false;
            string[] rankArray = new string[13] { "Private", "Private 2", "Private First Class", "Specialist", "Corporal", "Sergeant", "Staff Sergeant", "Sergeant First Class", "Master Sergeant", "First Sergeant", "Sergeant Major", "Command Sergeant Major", "Sergeant Major of the Army" };

            foreach (User item in ReadAllList)
            {

                for (int i = 0; i < rankArray.Length; i++)
                {
                    if (item.Username == username && item.Password == password && item.Rank == rankArray[i] && i<=10)
                    {
                        isValid = true;
                        TheAdminApp TheApp = new TheAdminApp(item);
                        this.Hide();
                        TheApp.ShowDialog();
                        this.Close();
                        break;
                    }
                    else if (item.Username == username && item.Password == password && item.Rank == rankArray[i] && i > 10)
                    {
                        isValid = true;
                        TheAdminApp TheAdminApp = new TheAdminApp(item);
                        this.Hide();
                        TheAdminApp.ShowDialog();
                        this.Close();
                        break;
                    }

                }
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("You left something open");
                    break;
                }
                else if (isValid == false)
                {
                    MessageBox.Show("Wrong Username/Password");
                    TxtUsername.Clear();
                    TxtPassword.Clear();
                    break;
                }

            }




        }

        private void PasswordCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (PasswordCheckBox.Checked)
            {
                TxtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                TxtPassword.UseSystemPasswordChar = true;
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnShowPassword_Click(object sender, EventArgs e)
        {
            if (PasswordCheckBox.Checked)
            {
                PasswordCheckBox.Checked = false;
            }
            else
            {
                PasswordCheckBox.Checked = true;
            }
            
        }
    }
}
