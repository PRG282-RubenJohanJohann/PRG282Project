﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class MessageControll : UserControl
    {
        private User user;
        public MessageControll(User user) : base(user)
        {
            InitializeComponent();
            this.user = user;
        }
        
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            BindingSource bs = new BindingSource();
            bs.DataSource = controller.ReadAllDmController();
            dgvMessage.DataSource = bs;
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            Decrypt decrypting = new Decrypt();
            string path = txtPath.Text;
            List<string> decryptedList = new List<string>();
            decryptedList = decrypting.FullyDecrypt(path);
            string line = "";
            foreach (string word in decryptedList)
            {
                if (line != "")
                {
                    line = string.Format("{0}{1}", line, word);
                }
                else
                {
                    line = word;
                }
            }
            DatabaseMessage dm = new DatabaseMessage(line, user.Name);
        }
    }
}
