﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Login
{
    class Controller
    {
        DataHandler dh = new DataHandler();
        public List<User> ReadAllOfficersController()
        {
            List<User> MyList = new List<User>();

            DataTable dt = new DataTable();
            dt = dh.ReadAllOfficers();

            foreach (DataRow item in dt.Rows)
            {
                MyList.Add(new User(item.ItemArray[0].ToString(), item.ItemArray[1].ToString(), int.Parse(item.ItemArray[2].ToString()), item.ItemArray[3].ToString(), long.Parse(item.ItemArray[4].ToString()), item.ItemArray[5].ToString(), item.ItemArray[6].ToString()));
            }
            return MyList;
        }

        public int UpdateOfficerController(string name, string surname, int age, string rank, string username, string password)
        {
            int result = dh.UpdateOfficer(name, surname, age, rank, username, password);
            if (result>0)
            {
                return result;
            }
            else
            {
                return result;
            }
        }
        public int DeleteOfficerController(string username)
        {
            int result = dh.DeleteOfficer(username);
            if (result > 0)
            {
                return result;
            }
            else
            {
                return result;
            }
        }

        public int InsertOfficerController(string name, string surname, int age, string rank, string username, string password)
        {
            int result = dh.InsertOfficer(name, surname, age, rank, username, password);
            if (result > 0)
            {
                return result;
            }
            else
            {
                return result;
            }
        }
        public List<User> ReadAllDmController()
        {
            List<User> MyList = new List<User>();

            DataTable dt = new DataTable();
            dt = dh.ReadAllDm();

            foreach (DataRow item in dt.Rows)
            {
                MyList.Add(new User(item.ItemArray[0].ToString(), item.ItemArray[1].ToString(), int.Parse(item.ItemArray[2].ToString()), item.ItemArray[3].ToString(), long.Parse(item.ItemArray[4].ToString()), item.ItemArray[5].ToString(), item.ItemArray[6].ToString()));
            }
            return MyList;
        }

        public int InsertDm(DateTime date, string message, string domain, string identification)
        {
            int result = dh.InsertDm(date, message, domain, identification);

            if (result > 0)
            {
                return result;
            }
            else
            {
                return result;
            }
        }

        public List<string> GetEncryptedFile(string path)
        {
            Filehandler fh = new Filehandler();
            List<string> EncryptedList = new List<string>();
            EncryptedList = fh.GetEncryptedFile(path);

            return EncryptedList;
        }
    }
}
