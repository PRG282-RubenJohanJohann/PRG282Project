﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Login
{
    class Decrypt
    {
        public List<string> FullyDecrypt(string path)
        {
            List<string> EncryptedList = new List<string>();
            List<string> DecryptedList = new List<string>();
            List<string> convertedList = new List<string>();
            Controller c = new Controller();
            EncryptedList = c.GetEncryptedFile(path);


            foreach (string item in EncryptedList)
            {
                string[] dataBin = item.Split(' ');

                convertedList = BinaryToString(dataBin);
                string decodedString = "";

                foreach (string word in convertedList)
                {
                    if (decodedString != "")
                    {
                        decodedString = string.Format("{0}{1}", decodedString, word);
                    }
                    else
                    {
                        decodedString = word;
                    }
                }


                for (int i = 1; i <= 8; i++)
                {
                    char[] charArray = decodedString.ToCharArray();
                    for (int j = 0; j < charArray.Length; j++)
                    {
                        char letter = charArray[j];

                        letter = (char)(letter - i);

                        charArray[j] = letter;
                    }

                    string decryptedString = new string(charArray);
                    string[] words = decryptedString.Split(' ');
                    List<string> trimmedList = new List<string>();
                    trimmedList = RemoveDuplicates(words);
                    decryptedString = "";

                    foreach (string word in trimmedList)
                    {
                        if (decryptedString != "")
                        {
                            decryptedString = string.Format("{0} {1}", decryptedString, word);
                        }
                        else
                        {
                            decryptedString = word;
                        }
                    }

                    if (trimmedList.Count() >= 5)
                    {
                        if (ValidWord(trimmedList))
                        {
                            DecryptedList.Add(decryptedString);

                            //string phrase = Palindrome(trimmedList);

                            // if (phrase != "")
                            // {
                            //    Mail sendMail = new Mail();
                            //    sendMail.SendEmergency(decryptedString, phrase);
                            // }

                            break;
                        }
                        else
                        {
                            if (i == 8)
                            {
                                DecryptedList.Add("Incomplete transmission received");
                            }
                        }
                    }
                    else
                    {
                        if (i == 8)
                        {
                            DecryptedList.Add("Incomplete transmission received");
                        }
                    }
                }
            }
            return DecryptedList;
        }

        private List<string> BinaryToString(string[] data)
        {
            List<string> decodedList = new List<string>();
            List<Byte> byteList = new List<Byte>();

            foreach (string item in data)
            {
                for (int i = 0; i < item.Length; i += 8)
                {
                    byteList.Add(Convert.ToByte(item.Substring(i, 8), 2));
                }
            }
            decodedList.Add(Encoding.ASCII.GetString(byteList.ToArray()));
            return decodedList;
        }

        private bool ValidWord(List<string> words)
        {
            int count = 0;
            NetSpell.SpellChecker.Dictionary.WordDictionary oDict = new NetSpell.SpellChecker.Dictionary.WordDictionary();

            oDict.DictionaryFile = "en-US.dic";
            oDict.Initialize();
            NetSpell.SpellChecker.Spelling oSpell = new NetSpell.SpellChecker.Spelling();
            oSpell.Dictionary = oDict;

            foreach (string item in words)
            {
                if (oSpell.TestWord(item))
                {
                    count++;
                }
            }

            if (count >= 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private List<string> RemoveDuplicates(string[] words)
        {
            List<string> uniqueWords = new List<string>();

            for (int i = 0; i < words.Count() - 1; i++)
            {
                if (words[i].ToString() != words[i + 1].ToString())
                {
                    uniqueWords.Add(words[i].ToString());
                }
            }
            uniqueWords.Add(words[words.Count() - 1].ToString());


            return uniqueWords;
        }

        //private string Palindrome(List<string> uniqueWords)
        // {
        //  string phrase = "";
        // foreach (string word in uniqueWords)
        //  {
        // phrase = phrase + word[0];
        // }
        //List[string]
        // for (int i = 0; i < phrase.Length - 1; i++)
        // {

        // }
        // char[] charArray = phrase.ToCharArray();
        // if (phrase == Array.Reverse(charArray))
        // {
        //    return phrase;
        // }

        // else return "";
    }

}

