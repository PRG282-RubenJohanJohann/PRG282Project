﻿using System;
using System.Net.Mail;

namespace Login
{
    class Mail
    {
        public string SendEmergency(string message, string code)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("rubenjohanjohannproject@gmail.com");
                mail.To.Add("mcintyre.d@belgiumcampus.ac.za");
                mail.Subject = "Important!!";
                mail.Body = string.Format(@"{0} 
code:{1}", message, code);

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("rubenjohanjohannproject@gmail.com", "plsdonthackme");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                return "Message sent succesfully";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return "Message failed to send";
            }
        }
    }
}
