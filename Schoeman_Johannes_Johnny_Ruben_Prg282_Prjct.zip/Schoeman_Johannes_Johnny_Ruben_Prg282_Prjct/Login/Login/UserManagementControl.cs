﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Login
{
    public partial class UserManagementControl : UserControl
    {
        public UserManagementControl()
        {
            InitializeComponent();
        }

        private void UserManagementControl_Load(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            MessageBox.Show(string.Format("{0} Rows Affected",controller.InsertOfficerController(txtName.Text,txtSurname.Text,int.Parse(txtAge.Text),txtRank.Text, txtUsername.Text, txtPassword.Text)));
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            MessageBox.Show(string.Format("{0} Rows Affected", controller.UpdateOfficerController(txtName.Text,txtSurname.Text,int.Parse(txtAge.Text),txtRank.Text,txtUsername.Text, txtPassword.Text)));
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Controller controller = new Controller();
            MessageBox.Show(string.Format("{0} Rows Affected", controller.DeleteOfficerController(txtUsername.Text)));
        }
    }
}
