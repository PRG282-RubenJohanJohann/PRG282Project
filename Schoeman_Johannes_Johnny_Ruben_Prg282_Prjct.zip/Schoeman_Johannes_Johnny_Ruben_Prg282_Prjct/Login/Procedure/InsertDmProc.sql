CREATE PROCEDURE InsertDmProc
	@date date,
	@message VARCHAR(100),
	@domain VARCHAR(60),
	@identification BIGINT
AS
BEGIN
	INSERT INTO DecryptedMessage(DateCreated, Message, DomainName, Identification_number) VALUES(@date, @message, @domain, @identification)
END