CREATE PROCEDURE InsertOfficerProc
	
	@name VARCHAR(50),
	@surname VARCHAR(50),
	@age INT,
	@rank VARCHAR(50),
	@username VARCHAR(50),
	@password VARCHAR(50)
AS
BEGIN
	INSERT INTO tblOfficer(Name, Surname, Age, Rank, Username, Password) VALUES(@name, @surname, @age, @rank, @username, @password)
END