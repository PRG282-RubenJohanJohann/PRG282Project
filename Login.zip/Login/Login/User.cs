﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Login
{
    class User
    {
        private Int64 IdentificationNumber;
        private string name;
        private string surname;
        private int age;
        private string rank;
        private string username;
        private string password;

        public long IdentificationNumber1 { get => IdentificationNumber; set => IdentificationNumber = value; }
        public string Name { get => name; set => name = value; }
        public string Surname { get => surname; set => surname = value; }
        public int Age { get => age; set => age = value; }
        public string Rank { get => rank; set => rank = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }

        public User(string name, string surname, int age, string rank, long IdentificationNumber,string username, string password)
        {
            this.IdentificationNumber = IdentificationNumber;
            this.name = name;
            this.surname = surname;
            this.age = age;
            this.rank = rank;
            this.username = username;
            this.password = password;
        }
    }
}
