﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Login
{
    class DataHandler
    {
        //
        SqlConnection conn;
        //SqlConnectionStringBuilder builder;
        public DataHandler()
        {
           // builder = new SqlConnectionStringBuilder();
          //  builder.DataSource = @"localhost\SQLEXPRES";
           // builder.InitialCatalog = "Login";
           // builder.IntegratedSecurity = true;
            conn = new SqlConnection(@"Data Source=DESKTOP-RLPPP3A;Initial Catalog=Military;Integrated Security=True");
        }

        public DataTable ReadAll()
        {
            DataTable result = new DataTable();
            try
            {
                if (conn.State != ConnectionState.Open)
                {
                    conn.Open();
                }
                
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText="ReadAllProc";
                cmd.Connection = conn;
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(result);
                
                //cmd.Parameters.AddWithValue("@Username", username);
                //cmd.Parameters.AddWithValue("@Password", password);
                //result =int.Parse(cmd.ExecuteScalar().ToString());
            }
            catch (SqlException SqlEx)
            {
                MessageBox.Show(SqlEx.Message);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
            return result;
        }

        

    }
}
