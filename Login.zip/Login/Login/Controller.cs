﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Login
{
    class Controller
    {
        public List<User> ReadAllController()
        {
            List<User> MyList = new List<User>();
            DataHandler dh = new DataHandler();
            DataTable dt = new DataTable();
            dt = dh.ReadAll();

            foreach (DataRow item in dt.Rows)
            {
                MyList.Add(new User(item.ItemArray[0].ToString(), item.ItemArray[1].ToString(), int.Parse(item.ItemArray[2].ToString()), item.ItemArray[3].ToString(), long.Parse(item.ItemArray[4].ToString()), item.ItemArray[5].ToString(), item.ItemArray[6].ToString()));
            }
            return MyList;
        }
    }
}
