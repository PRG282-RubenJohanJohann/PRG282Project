﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp2
{
    class Filehandler
    {
        public List<string> GetEncryptedFile(string path)
        {
            List<string> fullList = new List<string>();
            string line = "";
            using (FileStream fs = new FileStream(path,FileMode.Open,FileAccess.Read))
            {
                StreamReader sr = new StreamReader(fs);
                while ((line=sr.ReadLine())!= null)
                {
                    fullList.Add(line);
                }
            }
            return fullList;
        }
    }
}
