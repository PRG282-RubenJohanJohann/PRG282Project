﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloseToFinal
{//NuGet console : PM> Install-Package NetSpell
    class Decrypt
    {
        public List<string> FullyDecrypt(string path)
        {
            List<string> EncryptedList = new List<string>();
            List<string> DecryptedList = new List<string>();
            Controller c = new Controller();
            EncryptedList = c.GetEncryptedFile(path);

            foreach (string item in EncryptedList)
            {
                string convertedString = BinaryToString(item.ToString());

                for (int i = 1; i <= 8; i++)
                {
                    char[] charArray = convertedString.ToCharArray();
                    for (int j = 0; j < charArray.Length; j++)
                    {
                        char letter = charArray[j];

                        letter = (char)(letter - i);

                        charArray[j] = letter;
                    }

                    string decryptedString = new string(charArray);
                    string[] words = decryptedString.Split(' ');
                    List<string> trimmedList = new List<string>();
                    trimmedList = RemoveDuplicates(words);
                    decryptedString = "";

                    foreach (string word in trimmedList)
                    {
                        if (decryptedString != "")
                        {
                            decryptedString = string.Format("{0} {1}", decryptedString, word);
                        }
                        else
                        {
                            decryptedString = word;
                        }
                    }

                    if (trimmedList.Count() >= 5)
                    {
                        if (ValidWord(trimmedList))
                        {
                            DecryptedList.Add(decryptedString);

                            string phrase = Palindrome(trimmedList);

                            if (phrase != "")
                            {
                                Mail sendMail = new Mail();
                                sendMail.SendEmergency(decryptedString, phrase);
                            }

                            break;
                        }
                        else
                        {
                            DecryptedList.Add("Incomplete transmission received");
                        }
                    }
                    else
                    {
                        DecryptedList.Add("Incomplete transmission received");
                    }
                }
            }
            return DecryptedList;
        }

        private string BinaryToString(string data)
        {
            List<Byte> byteList = new List<Byte>();

            for (int i = 0; i < data.Length; i += 8)
            {
                byteList.Add(Convert.ToByte(data.Substring(i, 8), 2));
            }
            return Encoding.ASCII.GetString(byteList.ToArray());
        }

        private bool ValidWord(List<string> words)
        {
            int count = 0;
            NetSpell.SpellChecker.Dictionary.WordDictionary oDict = new NetSpell.SpellChecker.Dictionary.WordDictionary();

            oDict.DictionaryFile = "en-US.dic";
            oDict.Initialize();
            NetSpell.SpellChecker.Spelling oSpell = new NetSpell.SpellChecker.Spelling();
            oSpell.Dictionary = oDict;

            foreach (string item in words)
            {
                if (oSpell.TestWord(item))
                {
                    count++;
                }
            }

            if (count >= 5)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private List<string> RemoveDuplicates(string[] words)
        {
            List<string> uniqueWords = new List<string>();

            for (int i = 0; i < words.Count() - 1; i++)
            {
                if (words[i].ToString() != words[i + 1].ToString())
                {
                    uniqueWords.Add(words[i].ToString());
                }
            }
            uniqueWords.Add(words[words.Count() - 1].ToString());


            return uniqueWords;
        }

        private string Palindrome(List<string> uniqueWords)
        {
            string phrase = "";
            foreach (string word in uniqueWords)
            {
                phrase = phrase + word[0];
            }
            if (phrase == (string)phrase.Reverse())
            {
                return phrase;
            }
            else return "";
        }
    }
}
