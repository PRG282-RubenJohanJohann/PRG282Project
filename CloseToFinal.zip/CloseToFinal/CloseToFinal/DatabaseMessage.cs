﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloseToFinal
{
    class DatabaseMessage
    {
        private DateTime curDate;
        private string message;
        private string user;

        public string User
        {
            get { return user; }
            set { user = value; }
        }


        public string Message
        {
            get { return message; }
            set { message = value; }
        }


        public DateTime CurDate
        {
            get { return curDate; }
            set { curDate = value; }
        }

        public DatabaseMessage(string message, string user)
        {
            this.message = message;
            this.user = user;
            this.curDate = DateTime.Now;
        }
    }
}
