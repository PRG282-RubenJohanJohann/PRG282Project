﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloseToFinal
{
    class Controller
    {
        public List<string> GetEncryptedFile(string path)
        {
            Filehandler fh = new Filehandler();
            List<string> EncryptedList = new List<string>();
            EncryptedList = fh.GetEncryptedFile(path);

            return EncryptedList;
        }
    }
}
