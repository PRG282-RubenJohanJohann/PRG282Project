﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {

        }


        public static bool IsPalindrome(List<string> uniqueWords)
        {
            string phrase = "";
            foreach (string word in uniqueWords)
            {
                phrase = phrase + word[0];
            }
            if (phrase == (string)phrase.Reverse())
            {
                return true;
            }
            else return false;
        }
        public static List<string> RemoveDuplicates(string[] words)
        {
            List<string> uniqueWords = new List<string>();
            for (int i = 0; i < words.Count() - 1; i++)
            {
                if (words[i].ToString() != words[i + 1].ToString())
                {
                    uniqueWords.Add(words[i].ToString());
                }
            }
            uniqueWords.Add(words[words.Count() - 1].ToString());//for loop won't iterate through last index of "words" so we add it
            return uniqueWords;
        }
    }

}
